MathGeoLib
==========

A C++ library for linear algebra and geometry manipulation for computer graphics.

* Homepage: http://clb.demon.fi/MathGeoLib/
* Source Code: https://github.com/juj/MathGeoLib
* Released Downloads: https://github.com/juj/MathGeoLib/tags
* License: http://www.apache.org/licenses/LICENSE-2.0.html
* Class Reference: http://clb.demon.fi/MathGeoLib/reference.html
* Bug Tracker: https://github.com/juj/MathGeoLib/issues
* IRC Channel: #MathGeoLib @ irc.afternet.org
* Forums: http://www.gamedev.net/
* Continuous Builds: http://clb.demon.fi:8113/waterfall
* Live HTML Interpreter: https://dl.dropbox.com/u/40949268/emcc/MathGeoLibTest.html
